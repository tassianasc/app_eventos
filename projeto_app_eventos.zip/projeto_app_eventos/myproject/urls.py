# myproject/urls.py
from django.contrib import admin  # Adicionando a importação do admin

from django.urls import path, include
from events import views

urlpatterns = [
    path('admin/', admin.site.urls),  # Corrigindo a definição do admin
    path('events/', include('events.urls')),
    path('', views.index, name='index'),
    path('<int:event_id>/', views.detail, name='detail'),
    path('create/', views.create_event, name='create_event'),
    path('<int:event_id>/edit/', views.edit_event, name='edit_event'),
]
